from project.mammal import Mammal


class Bear(Mammal):
    def __init__(selfself, name: str):
        super().__init__(name)
     